with open('bmark_output/fib.out', 'rb') as file:
    file.seek(-2, 2)  # Move the pointer to the second last byte of the file
    while file.read(1) != b'\n':  # Keep going back until we find a newline
        file.seek(-2, 1)  # Move back one byte at a time
    last_line = file.readline().decode()  # Read the last line
    print(last_line)

# f = open('bmark_output/fib.out', 'rb')
# lines = f.read()
# answer = lines.find(' 2178309')
# print(answer)
string = ' '+str(2178309) 
string = 'ALU=   5702887'
with open('bmark_output/fib.out', 'r') as inF:
    for line in inF:
        if string in line:
            print(line)
